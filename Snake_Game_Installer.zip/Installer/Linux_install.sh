sudo apt-get install python python-pygame libsdl1.2-dev && sudo apt-get autoremove
